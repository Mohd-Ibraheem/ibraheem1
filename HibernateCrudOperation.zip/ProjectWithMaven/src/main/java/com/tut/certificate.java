package com.tut;

import javax.persistence.Embeddable;

@Embeddable
public class certificate {
	
	private String cousre;
	private String duration;
	public String getCousre() {
		return cousre;
	}
	public void setCousre(String cousre) {
		this.cousre = cousre;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public certificate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public certificate(String cousre, String duration) {
		super();
		this.cousre = cousre;
		this.duration = duration;
	}
	
	

}
