package com.autoincreementtable;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class Test {

	public static void main(String[] args) {
		 System.out.println( "MY PROGRAM STARTED" );
	        
		           // springjdbc=>JdbcTemplate
		   
	        ApplicationContext context=new ClassPathXmlApplicationContext("com/autoincreementtable/Config.xml");
	            JdbcTemplate template=context.getBean("jdbcTemplate",JdbcTemplate.class);
	            
	            
	            //insert query.........>
	            String query="insert into employee(name,address) value(?,?)";
	            
	            //fire query.....>
	            int result = template.update(query,"Ozair","Lucknow");
	            System.out.println("Number Of Record Inserted.." + result);
	            		
	        
	    }

	}


